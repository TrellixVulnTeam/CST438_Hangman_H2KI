# CST438_Hangman
Week 1 Assignment

## Description
Create a hangman game using a server side languauge (in this case, python), use github and deploy to AWS.
